﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercício4
{
    internal class Mensalista : Empregado
    {
        public double Salariomensal { get; set; }

        public override double SalarioBruto()
        {
            return Salariomensal;
        }

    }
}
